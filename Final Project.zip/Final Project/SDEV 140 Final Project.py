### Author:  Clyde Kershaw
### Date written: /2023
### Assignment:  Final Project
### Description:   The intention of this tKinter Python application is to show the user a list of applicable hikes based on the distance the user wishes to hike.

def exit1():
    window1.destroy

def open1():
    window2 = Toplevel(window1)
    window2.geometry("500x500")
    window2.config(bg="white")
    window2.resizable(width=False,height=False)
    window2.title('List of Hikes')
    l1 = Label (window2,text="Five Hikes Under 4 Miles",font=("Times New Roman", 25),fg="black",bg="white")
    l1.pack()
    l2 = Label (window2,text= "Burr Oak Woods Loop \n Length: 0.9 mi \n Elevation Gain: 6 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black",bg="white")
    l2.pack()
    l3 = Label (window2,text= "Paul H. Douglas Trail \n Length: 3.5 mi \n Elevation Gain: 124 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black",bg="white")
    l3.pack()
    l4 = Label (window2,text= "Hobart Prarie Grove \n Length: 2.1 mi \n Elevation Gain: 38 ft \n Route Type: Out & Back \n City: Hobart, Indiana",font=("Arial", 10),fg="black",bg="white")
    l4.pack()
    l5 = Label (window2,text= "Greiner Nature Preserve Loop \n Length: 0.8 mi \n Elevation Gain: 3 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black",bg="white")
    l5.pack()
    l6 = Label (window2,text= "Cressmoor Prairie Nature Preserve Loop \n Length: 1.2 mi \n Elevation Gain: 13 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black",bg="white")
    l6.pack()
    btn1 = Button (window2,text="Click to return to choice of hike length",font=("Arial", 10),command= window2.destroy)
    btn1.pack()
    

def open2():
    window3 = Toplevel(window1)
    window3.geometry("500x500")
    window3.config(bg="white")
    window3.resizable(width=False,height=False)
    window3.title('List of Hikes')
    l1 = Label (window3,text="Five Hikes Between 4 and 10 Miles",font=("Times New Roman", 25),fg="black",bg="white")
    l1.pack()
    l2 = Label (window3,text= "Marquette Trail \n Length: 4.7 mi \n Elevation Gain: 173 ft \n Route Type: Out & Back \n City: Portage, Indiana",font=("Arial", 10),fg="black",bg="white")
    l2.pack()
    l3 = Label (window3,text= "Imagination Glen \n Length: 6.9 mi \n Elevation Gain: 213 ft \n Route Type: Loop \n City: Chesterton, Indiana",font=("Arial", 10),fg="black",bg="white")
    l3.pack()
    l4 = Label (window3,text= "Creekside Trails Outer Loop \n Length: 4.3 mi \n Elevation Gain: 203 ft \n Route Type: Loop \n City: Valparaiso, Indiana",font=("Arial", 10),fg="black",bg="white")
    l4.pack()
    l5 = Label (window3,text= "Cowles Bog Trail \n Length: 4.3 mi \n Elevation Gain: 216 ft \n Route Type: Loop \n City: Dune Acres, Indiana",font=("Arial", 10),fg="black",bg="white")
    l5.pack()
    l6 = Label (window3,text= "Calumet Trail \n Length: 9.2 mi \n Elevation Gain: 45 ft \n Route Type: Point-to-point \n City: Dune Acres, Indiana",font=("Arial", 10),fg="black",bg="white")
    l6.pack()
    btn1 = Button (window3,text="Click to return to choice of hike length",font=("Arial", 10),command= window3.destroy)
    btn1.pack()
    
def open3():
    window4 = Toplevel(window1)
    window4.geometry("500x500")
    window4.config(bg="white")
    window4.resizable(width=False,height=False)
    window4.title('List of Hikes')
    l1 = Label (window4,text="Five Hikes Over 10 Miles",font=("Times New Roman", 25),fg="black",bg="white")
    l1.pack()
    l2 = Label (window4,text= "Prairie Duneland Trail \n Length: 10.3 mi \n Elevation Gain: 55 ft \n Route Type: Point-to-point \n City: Chesterton, Indiana",font=("Arial", 10),fg="black",bg="white")
    l2.pack()  
    l3 = Label (window4,text= "Oak Savannah Trail \n Length: 18.1 mi \n Elevation Gain: 269 ft \n Route Type: Out & Back \n City: Hobart, Indiana",font=("Arial", 10),fg="black",bg="white")
    l3.pack()   
    l4 = Label (window4,text= "Little Calumet Levee Trail - East \n Length: 12.3 mi \n Elevation Gain: 45 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black",bg="white")
    l4.pack()
    l5 = Label (window4,text= "Little Calumet Levee Trail - West \n Length: 13.3 mi \n Elevation Gain: 65 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black",bg="white")
    l5.pack()
    l6 = Label (window4,text= "Erie Lackawanna Trail \n Length: 16.9 mi \n Elevation Gain: 127 ft \n Route Type: Point-to-point \n City: Crown Point, Indiana",font=("Arial", 10),fg="black",bg="white")
    l6.pack()
    btn1 = Button (window4,text="Click to return to choice of hike length",font=("Arial", 10),command= window4.destroy)
    btn1.pack()

from tkinter import *
from PIL import ImageTk, Image
window1 = Tk()
window1.geometry("500x500")
window1.config(bg="white")
window1.resizable(width=True,height=True)
window1.title('Hike Length Choice')
 
l1 = Label(window1,text="GoHike",font=("Arial", 25),fg="black",bg="white")
l2= Label(window1,text="Pick a hike length: ",font=("Arial", 10,"bold"),bg="white")
 
 
btn1 = Button(window1,text="I want to hike less than 4 miles",font=("Arial", 10),command=open1)
btn2 = Button(window1,text="I want to hike between 4 and 10 miles",font=("Arial", 10),command=open2)
btn3 = Button(window1,text="I want to hike more than 10 miles",font=("Arial", 10),command=open3)
btn4 = Button(window1,text="Exit application",font=("Arial", 10),command=exit)

my_img = ImageTk.PhotoImage(Image.open("homeimg.jpg"))
my_label= Label(image=my_img) 


l1.pack()
my_label.pack()
l2.pack()
btn1.pack()
btn2.pack()
btn3.pack()
btn4.pack()

 
window1.mainloop()

