### Author:  Clyde Kershaw
### Date written: 3/7/2023
### Assignment:  Final Project
### Description:   The intention of this tKinter Python application is to show the user a list of applicable hikes based on the distance the user wishes to hike. This program is fully documented and has the potential to be expanded in the future. The comments in this program are as follows: each new variable is commented, and each comment is on its own line. Repeated comments regarding similar variables are not commented for simplicity, as some of the code repeatedly uses the same variable name or creates similar results. 


def get_name():     #Prompt the user to enter their name
    name1 = name.get()      #Assigns the user's name to the variable name1
    if name1.isalpha() and len(name1) > 0:      #Checks to see if the user entered a valid name
        open1()     #If the user entered a valid name, open the hike list choice page
    else:       #If the user did not enter a valid name, prompt them to enter a valid name, and return to the main menu
        window6 = Toplevel(window1)     #creates a new toplevel child window with the master window window1 as the parent
        window6.geometry("500x500")     #configures the window to be 500x500
        window6.config(bg="white")      #configures the window to be white
        window6.resizable(width=False,height=False)     #configures the window to not be resizable
        window6.title('Error')      #configures the window to have a title
        l1 = Label(window6,text="You must enter your name to continue",font=("Arial", 20),fg="black",bg="white")        #creates a label with the text "You must enter your name to continue"
        l1.pack()       #packs the label onto the window
        btn1 = Button(window6,text="OK",font=("Arial", 10), command=window6.destroy)        #creates a button with the text "OK"
        btn1.pack()
       
def open1():        #Opens the hike list choice page
    window5 = Toplevel(window1)    #creates a new toplevel child window with the master window window1 as the parent
    window5.geometry("500x500")    #configures the window to be 500x500
    window5.config(bg="white")     #configures the window to be white
    window5.resizable(width=False,height=False)    #configures the window to not be resizable
    window5.title('Hike Length Choice')     #configures the window to have a title

    main_frame = Frame(window5)     #creates a frame for window5
    main_frame.pack(fill = BOTH, expand = 1)        #packs the frame onto the child window window5
 
    my_canvas = Canvas(main_frame)      #creates a canvas on the main frame
    my_canvas.pack(side = RIGHT, fill= BOTH, expand = 1)        #packs the canvas onto the child window window5

    frame_two = Frame(my_canvas)        #creates a frame called frame_two and places it on the canvas      
    
    my_canvas.create_window((0,0), window = frame_two, anchor = NW)     #creates a window on the canvas called frame_two
    
    canvas = Canvas(frame_two,width=365,height=210)     #creates a canvas called canvas and places it on the frame_two
    img = (Image.open("homeimg.jpg"))       #creates an Image object representing the home image
    resized_image1= img.resize((365,210),Image.ANTIALIAS)       #resizes the image to 365x210 pixels
    img1 =ImageTk.PhotoImage(resized_image1)        #assigns the image to a PhotoImage object img1
    canvas.create_image(0,0,image=img1, anchor=NW)      #places the image on the canvas at (0,0)
    canvas.image = img1     #assigns the image to the canvas image variable

    l1 = Label(frame_two,text="GoHike",font=("Arial", 25),fg="black")       #Creates a title label with the text "GoHike"
    l1.pack()       #packs the label onto the frame_two

    canvas.pack()    #packs the canvas onto the frame_two
    
    l2= Label(frame_two,text="Pick a hike length: ",font=("Arial", 10,"bold"), padx= 190)       #creates a label with the text "Pick a hike length: "
    l2.pack()       #packs the label onto the frame_two
    
    btn1 = Button(frame_two,text="I want to hike less than 4 miles",font=("Arial", 10),command=open2)       #creates a button with the text "I want to hike less than 4 miles"
    btn1.pack()     #packs the button onto the frame_two
    
    btn2 = Button(frame_two,text="I want to hike between 4 and 10 miles",font=("Arial", 10),command=open3)      #creates a button with the text "I want to hike between 4 and 10 miles"
    btn2.pack()     #packs the button onto the frame_two
    
    btn3 = Button(frame_two,text="I want to hike more than 10 miles",font=("Arial", 10),command=open4)      #creates a button with the text "I want to hike more than 10 miles"
    btn3.pack()    #packs the button onto the frame_two
    
    btn4 = Button(frame_two,text="Exit application",font=("Arial", 10),command=exit)        #creates an exit button with the text "Exit application"
    btn4.pack()     #packs the button onto the frame_two
    

def open2():        #Opens the list of hikes less than 4 miles page
    window2 = Toplevel(window1)     #creates a new toplevel child window with the master window window1 as the parent
    window2.geometry("400x500")    #configures the window to be 400x500
    window2.config(bg="white")      #configures the window to be white
    window2.resizable(width=False,height=True)      #configures the window to be resizable in height but not width
    window2.title('List of Hikes')      #configures the window to have a title of "List of Hikes"

    main_frame = Frame(window2)     #creates a frame for the main window called main_frame
    main_frame.pack(fill = BOTH, expand = 1)        #packs the frame onto the main window

    my_canvas = Canvas(main_frame)      #creates a canvas called my_canvas within the frame called main_frame
    my_canvas.pack(side = LEFT, fill= BOTH, expand = 1)     #packs the canvas on the left side of the frame called main_frame

    my_scrollbar = ttk.Scrollbar(main_frame, orient = VERTICAL, command = my_canvas.yview)      #creates a scrollbar for the canvas called my_scrollbar
    my_scrollbar.pack(side = RIGHT, fill = Y)   #packs the scrollbar on the right side of the canvas called my_scrollbar

    my_canvas.configure(yscrollcommand = my_scrollbar.set)      #configures the scrollbar for the canvas
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))      #binds the canvas to the scrollregion

    frame_two = Frame(my_canvas)        #creates a frame called frame_two
    
    my_canvas.create_window((0,0), window = frame_two, anchor = NW)     #creates a window at (0,0) and places it in the frame called frame_two

    l1 = Label (frame_two,text="Five Hikes Under 4 Miles",font=("Times New Roman", 25),fg="black", padx= 25)        #creats the header label with the text "Five Hikes Under 4 Miles"
    l1.pack()       #packs the label onto the frame called frame_two
    
    l2 = Label (frame_two,text= "Burr Oak Woods Loop \n Length: 0.9 mi \n Elevation Gain: 6 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black") #creates the label with the text for the first hike
    l2.pack()       #packs the label onto the frame called frame_two
    
    canvas = Canvas(frame_two,width=125,height=125)       #creates a canvas called canvas with the width and height of 125 and 125
    img = (Image.open("img1.jpg"))      #creates an image called img with the path of img1.jpg
    resized_image1= img.resize((125,125),Image.ANTIALIAS)       #creates an image called resized_image1 with the path of img1.jpg that is resized to 125x125
    img1 =ImageTk.PhotoImage(resized_image1)        #assigns the image to img1
    canvas.create_image(0,0,image=img1, anchor=NW)      #packs the image onto the canvas called canvas at (0,0)
    canvas.image = img1     #assigns the canvas image to the img1
    canvas.pack()       #packs the canvas onto the frame called frame_two       

    l3 = Label (frame_two,text= "Paul H. Douglas Trail \n Length: 3.5 mi \n Elevation Gain: 124 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black")
    l3.pack()

    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img2.jpg"))
    resized_image2= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image2)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l4 = Label (frame_two,text= "Hobart Prarie Grove \n Length: 2.1 mi \n Elevation Gain: 38 ft \n Route Type: Out & Back \n City: Hobart, Indiana",font=("Arial", 10),fg="black")
    l4.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img3.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l5 = Label (frame_two,text= "Greiner Nature Preserve Loop \n Length: 0.8 mi \n Elevation Gain: 3 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black")
    l5.pack()
        
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img4.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    l6 = Label (frame_two,text= "Cressmoor Prairie Nature Preserve Loop \n Length: 1.2 mi \n Elevation Gain: 13 ft \n Route Type: Loop \n City: Hobart, Indiana",font=("Arial", 10),fg="black")
    l6.pack()
        
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img5.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    btn1 = Button (frame_two,text="Click to return to choice of hike length",font=("Arial", 10),command= window2.destroy)
    btn1.pack()
    

def open3(): #Opens the list of hikes between 4 and 10 miles page
    window3 = Toplevel(window1)
    window3.geometry("510x500")
    window3.config(bg="white")
    window3.resizable(width=False,height=True)
    window3.title('List of Hikes')
    
    main_frame = Frame(window3)
    main_frame.pack(fill = BOTH, expand = 1)

    my_canvas = Canvas(main_frame)
    my_canvas.pack(side = LEFT, fill= BOTH, expand = 1)

    my_scrollbar = ttk.Scrollbar(main_frame, orient = VERTICAL, command = my_canvas.yview)
    my_scrollbar.pack(side = RIGHT, fill = Y)

    my_canvas.configure(yscrollcommand = my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))

    frame_two = Frame(my_canvas)
    
    my_canvas.create_window((0,0), window = frame_two, anchor = NW)
    
    l1 = Label (frame_two,text="Five Hikes Between 4 and 10 Miles",font=("Times New Roman", 25),fg="black",padx= 15)
    l1.pack()
    
    l2 = Label (frame_two,text= "Marquette Trail \n Length: 4.7 mi \n Elevation Gain: 173 ft \n Route Type: Out & Back \n City: Portage, Indiana",font=("Arial", 10),fg="black")
    l2.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img6.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    l3 = Label (frame_two,text= "Imagination Glen \n Length: 6.9 mi \n Elevation Gain: 213 ft \n Route Type: Loop \n City: Chesterton, Indiana",font=("Arial", 10),fg="black")
    l3.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img7.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    l4 = Label (frame_two,text= "Creekside Trails Outer Loop \n Length: 4.3 mi \n Elevation Gain: 203 ft \n Route Type: Loop \n City: Valparaiso, Indiana",font=("Arial", 10),fg="black")
    l4.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img8.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    l5 = Label (frame_two,text= "Cowles Bog Trail \n Length: 4.3 mi \n Elevation Gain: 216 ft \n Route Type: Loop \n City: Dune Acres, Indiana",font=("Arial", 10),fg="black")
    l5.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img9.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    l6 = Label (frame_two,text= "Calumet Trail \n Length: 9.2 mi \n Elevation Gain: 45 ft \n Route Type: Point-to-point \n City: Dune Acres, Indiana",font=("Arial", 10),fg="black")
    l6.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img10.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()

    btn1 = Button (frame_two,text="Click to return to choice of hike length",font=("Arial", 10),command= window3.destroy)
    btn1.pack()
    
def open4(): #Opens the list of hikes over 10 miles page
    window4 = Toplevel(window1)
    window4.geometry("400x500")
    window4.config(bg="white")
    window4.resizable(width=False,height=False)
    window4.title('List of Hikes')

    main_frame = Frame(window4)
    main_frame.pack(fill = BOTH, expand = 1)

    my_canvas = Canvas(main_frame)
    my_canvas.pack(side = LEFT, fill= BOTH, expand = 1)

    my_scrollbar = ttk.Scrollbar(main_frame, orient = VERTICAL, command = my_canvas.yview)
    my_scrollbar.pack(side = RIGHT, fill = Y)

    my_canvas.configure(yscrollcommand = my_scrollbar.set)
    my_canvas.bind('<Configure>', lambda e: my_canvas.configure(scrollregion = my_canvas.bbox("all")))

    frame_two = Frame(my_canvas)
    
    my_canvas.create_window((0,0), window = frame_two, anchor = NW)
    
    l1 = Label (frame_two,text="Five Hikes Over 10 Miles",font=("Times New Roman", 25),fg="black", padx=25)
    l1.pack()
    
    l2 = Label (frame_two,text= "Prairie Duneland Trail \n Length: 10.3 mi \n Elevation Gain: 55 ft \n Route Type: Point-to-point \n City: Chesterton, Indiana",font=("Arial", 10),fg="black")
    l2.pack()  
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img11.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l3 = Label (frame_two,text= "Oak Savannah Trail \n Length: 18.1 mi \n Elevation Gain: 269 ft \n Route Type: Out & Back \n City: Hobart, Indiana",font=("Arial", 10),fg="black")
    l3.pack()   
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img12.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l4 = Label (frame_two,text= "Little Calumet Levee Trail - East \n Length: 12.3 mi \n Elevation Gain: 45 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black")
    l4.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img13.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l5 = Label (frame_two,text= "Little Calumet Levee Trail - West \n Length: 13.3 mi \n Elevation Gain: 65 ft \n Route Type: Out & Back \n City: Gary, Indiana",font=("Arial", 10),fg="black")
    l5.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img14.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)
    canvas.image = img1
    canvas.pack()
    
    l6 = Label (frame_two,text= "Erie Lackawanna Trail \n Length: 16.9 mi \n Elevation Gain: 127 ft \n Route Type: Point-to-point \n City: Crown Point, Indiana",font=("Arial", 10),fg="black")
    l6.pack()
    
    canvas = Canvas(frame_two,width=125,height=125)
    img = (Image.open("img15.jpg"))
    resized_image1= img.resize((125,125),Image.ANTIALIAS)       
    img1 =ImageTk.PhotoImage(resized_image1)
    canvas.create_image(0,0,image=img1, anchor=NW)   
    canvas.image = img1 
    canvas.pack()       
    
    btn1 = Button (frame_two,text="Click to return to choice of hike length",font=("Arial", 10),command= window4.destroy)     
    btn1.pack()    


from tkinter import *       #imports the tkinter module
from PIL import ImageTk, Image      #imports the PIL module
from tkinter import ttk     #imports the ttk module


window1 = Tk()      #initializes the main window
window1.geometry("500x500")     #sets the size of the main window to 500x500
window1.config(bg="white")      #initializes the window's background color to be white  
window1.resizable(width=True,height=True)       #configures the window to be resizable with width and height
window1.title('GoHike: Enter your name')        #initializes the title of the window
 
l1 = Label(window1,text="GoHike",font=("Arial", 25),fg="black",bg="white")      #initializes the header label for the main window
l2= Label(window1,text="Enter your name: ",font=("Arial", 10,"bold"),bg="white")        #Initializes the extry box label for the main window

name = Entry(window1)       #initializes the entry box for which the users name will be entered

btn1 = Button(window1,text="Submit",font=("Arial", 10),command=get_name)        #initializes the submit button
btn2 = Button(window1,text="Exit application",font=("Arial", 10),command=exit)      #initializes the exit button


    


my_img = ImageTk.PhotoImage(Image.open("homeimg.jpg")) #opens the home image and assigns it to my_img
my_label= Label(image=my_img) #places the image in the label my_label

l1.pack()   #packs the label in the main window
my_label.pack()  #packs the image within the label in the main window
l2.pack()  #packs the label in the main window
name.pack()  #packs the label in the main window
btn1.pack()  #packs the button in the main window
btn2.pack()  #packs the button in the main window

 
window1.mainloop() #starts the main loop

